#def get_integers():
    #rows = input('Enter a number for the rows:')
    #columns = input ('Enter a number for the columns:')
    #display_table(rows,columns)

#def display_table(rows, columns):
    #rows = int(rows)
    #columns = int(columns)+1
    #length = 5*(columns-rows+1)

    #print("{:>4}|".format(""), end= "")
    #for column in range(rows, columns):
        #print("{:>5}".format(str(column)), end="")
    #print()

    #for row in range(rows, columns):
        #print("-"*length)
        #print("{:>4}|".format(row), end="")
        #for column in range(rows, columns):
            #print("{:>5}".format(row*column), end="")
        #print()
    #print()

    #def main():
        #get_integers()

    #if __name__== "__main__":
        #main()

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
open()